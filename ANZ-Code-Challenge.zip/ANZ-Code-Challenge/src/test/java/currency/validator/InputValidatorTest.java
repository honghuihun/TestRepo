package currency.validator;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class InputValidatorTest {
    private InputValidator inputValidator;

    @Before
    public void setup() {
        inputValidator = new InputValidator();
    }

    @Test
    public void testValidateWithInvalidInput(){
        assertFalse(inputValidator.validate(null));
        assertFalse(inputValidator.validate(""));
        assertFalse(inputValidator.validate("   "));
        assertFalse(inputValidator.validate("JPY 100 in USD USD"));
        assertFalse(inputValidator.validate("JPY USD in USD"));
    }

    @Test
    public void testValidateWithValidInput(){
        assertTrue(inputValidator.validate("JPY 100 in USD"));
        assertTrue(inputValidator.validate("JPY 100.00 in USD"));
        assertTrue(inputValidator.validate("JPY 1 in USD"));
        assertTrue(inputValidator.validate("JPY -1 in USD"));
        assertTrue(inputValidator.validate("JPY 0 in USD"));
    }
}
