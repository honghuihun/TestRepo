package currency.validator;

import currency.model.Currency;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class CurrencyValidatorTest {

    private CurrencyValidator currencyValidator;
    private List<Currency> ccyList;

    @Before
    public void setup() {
        currencyValidator = new CurrencyValidator();
        ccyList = new ArrayList<>();
        addMockCurrencyListData();
    }

    @Test
    public void testValidateWithInvalidCcy(){
        assertFalse(currencyValidator.validate("usd", ccyList));
        assertFalse(currencyValidator.validate("aud", ccyList));
        assertFalse(currencyValidator.validate("", ccyList));
        assertFalse(currencyValidator.validate("0", ccyList));
        assertFalse(currencyValidator.validate("abc", ccyList));

        assertFalse(currencyValidator.validate("usd", "CAD", ccyList));
        assertFalse(currencyValidator.validate("AUD", "cad", ccyList));
        assertFalse(currencyValidator.validate("", "", ccyList));
        assertFalse(currencyValidator.validate("0", "0", ccyList));
        assertFalse(currencyValidator.validate("abc", "abc", ccyList));
    }

    @Test
    public void testValidateWithValidCcy(){
        assertTrue(currencyValidator.validate("USD", ccyList));
        assertTrue(currencyValidator.validate("CAD", ccyList));
        assertTrue(currencyValidator.validate("USD", "CAD", ccyList));
        assertTrue(currencyValidator.validate("USD", "AUD", ccyList));
    }

    private void addMockCurrencyListData(){
        Currency usd = new Currency("USD");
        Currency aud = new Currency("AUD");
        Currency cad = new Currency("CAD");
        Currency cny = new Currency("CNY");
        Currency nzd = new Currency("NZD");
        ccyList.add(usd);
        ccyList.add(aud);
        ccyList.add(cad);
        ccyList.add(cny);
        ccyList.add(nzd);
    }
}
