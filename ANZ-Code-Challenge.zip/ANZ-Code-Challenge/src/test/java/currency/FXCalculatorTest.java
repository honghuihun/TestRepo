package currency;

import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.math.RoundingMode;

import static org.junit.Assert.*;

public class FXCalculatorTest {

    private FXCalculator fxCalculator;
    @Before
    public void setup() {
        fxCalculator = new FXCalculator();
    }

    @Test
    public void testProcessRequestWithIncorrectInputFormat(){
        assertEquals(fxCalculator.processRequest(""), fxCalculator.INPUT_FORMAT_INCORRECT);
        assertEquals(fxCalculator.processRequest("AUD 100.00 in"), fxCalculator.INPUT_FORMAT_INCORRECT);
        assertEquals(fxCalculator.processRequest("AUD abc in USD"), fxCalculator.INPUT_FORMAT_INCORRECT);
        assertEquals(fxCalculator.processRequest("AUD in USD"), fxCalculator.INPUT_FORMAT_INCORRECT);
    }

    @Test
    public void testProcessRequestReturnUnableToFindRate(){
        assertEquals(fxCalculator.processRequest("ZBC 100.00 in USD"), String.format(fxCalculator.UNABLE_TO_FIND_RATE, "ZBC", "USD"));
        assertEquals(fxCalculator.processRequest("USD 100.00 in ZBC"), String.format(fxCalculator.UNABLE_TO_FIND_RATE, "USD", "ZBC"));
        assertEquals(fxCalculator.processRequest("ABC 100.00 in ZBC"), String.format(fxCalculator.UNABLE_TO_FIND_RATE, "ABC", "ZBC"));
    }

    @Test
    public void testProcessRequestReturnConvertResult(){
        assertEquals(fxCalculator.processRequest("AUD 100.00 in USD"), String.format(fxCalculator.CONVERT_RESULT, "AUD", "100.00", "USD", "83.71"));
        assertEquals(fxCalculator.processRequest("JPY 100 in USD"), String.format(fxCalculator.CONVERT_RESULT, "JPY", "100", "USD", "0.83"));
        assertEquals(fxCalculator.processRequest("AUD 100.00 in JPY"), String.format(fxCalculator.CONVERT_RESULT, "AUD", "100.00", "JPY", "10041"));
        assertEquals(fxCalculator.processRequest("AUD 100.00 in NOK"), String.format(fxCalculator.CONVERT_RESULT, "AUD", "100.00", "NOK", "589.00"));
    }

    @Test
    public void testFxCalculateReturnUnableToFindRate(){
        assertEquals(fxCalculator.fxCalculate("AUD", "ZBC", "100.00"),
                String.format(fxCalculator.UNABLE_TO_FIND_RATE, "AUD", "ZBC"));
        assertEquals(fxCalculator.fxCalculate("ZBC", "AUD", "100.00"),
                String.format(fxCalculator.UNABLE_TO_FIND_RATE, "ZBC", "AUD"));
        assertEquals(fxCalculator.fxCalculate("ABC", "DEF", "100.00"),
                String.format(fxCalculator.UNABLE_TO_FIND_RATE, "ABC", "DEF"));
    }

    @Test
    public void testFxCalculateReturnConvertResult(){
        assertEquals(fxCalculator.fxCalculate("AUD", "USD", "100.00"),
                String.format(fxCalculator.CONVERT_RESULT, "AUD", "100.00", "USD", "83.71"));
        assertEquals(fxCalculator.fxCalculate("JPY", "USD", "100.00"),
                String.format(fxCalculator.CONVERT_RESULT, "JPY", "100.00", "USD", "0.83"));
        assertEquals(fxCalculator.fxCalculate("AUD", "JPY", "100.00"),
                String.format(fxCalculator.CONVERT_RESULT, "AUD", "100.00", "JPY", "10041"));
        assertEquals(fxCalculator.fxCalculate("AUD", "NOK", "100.00"),
                String.format(fxCalculator.CONVERT_RESULT, "AUD", "100.00", "NOK", "589.00"));
    }

    @Test
    public void testGenerateUnableToFindRateResult(){
        assertEquals(fxCalculator.generateUnableToFindRateResult("ZBC", "USD"), String.format(fxCalculator.UNABLE_TO_FIND_RATE, "ZBC", "USD"));
        assertEquals(fxCalculator.generateUnableToFindRateResult("AUD", "CAD"), String.format(fxCalculator.UNABLE_TO_FIND_RATE, "AUD", "CAD"));
    }

    @Test
    public void testConvert(){
        BigDecimal convertedValue = fxCalculator.convert("AUD","USD",null, BigDecimal.valueOf(100.00)).setScale(2, RoundingMode.HALF_UP);
        assertEquals("83.71", convertedValue.toPlainString());

        convertedValue = fxCalculator.convert("USD","JPY",null, BigDecimal.valueOf(100.00)).setScale(0, RoundingMode.HALF_UP);
        assertEquals("11995", convertedValue.toPlainString());

        convertedValue = fxCalculator.convert("JPY","NOK",null, BigDecimal.valueOf(100.00)).setScale(2, RoundingMode.HALF_UP);
        assertEquals("5.87", convertedValue.toPlainString());

        convertedValue = fxCalculator.convert("AUD","NOK",null, BigDecimal.valueOf(100.00)).setScale(2, RoundingMode.HALF_UP);
        assertEquals("589.00", convertedValue.toPlainString());
    }
}
