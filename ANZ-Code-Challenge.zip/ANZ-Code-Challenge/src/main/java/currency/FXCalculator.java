package currency;

import currency.model.CrossViaTypeEnum;
import currency.model.Currency;
import currency.model.CurrencyPairRate;
import currency.resources.loader.CrossViaMatrixLoader;
import currency.resources.loader.CurrencyLoader;
import currency.resources.loader.CurrencyPairRatesLoader;
import currency.validator.CurrencyValidator;
import currency.validator.InputValidator;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class FXCalculator {
    private InputValidator inputValidator;
    private CurrencyValidator currencyValidator;
    private String[][] crossViaMatrix;
    private List<Currency> ccyList;
    private List<CurrencyPairRate> ccyPairRateList;
    public static final String INPUT_FORMAT_INCORRECT = "Input incorrect, please input correct format like 'AUD 100.00 in USD'";
    public static final String UNABLE_TO_FIND_RATE = "Unable to find rate for %s/%s";
    public static final String CONVERT_RESULT = "%s %s = %s %s";

    public FXCalculator(){
        inputValidator = new InputValidator();
        currencyValidator = new CurrencyValidator();
        ccyList = CurrencyLoader.loadCurrencyDisplayPrecision();
        ccyPairRateList = CurrencyPairRatesLoader.loadCurrencyPairRates();
        crossViaMatrix = CrossViaMatrixLoader.loadCrossViaMatrix();
    }

    public String processRequest(String input) {
        if(inputValidator.validate(input)){
            String[] inputElement = input.split("\\s+");
            String baseCcyCode = inputElement[0].trim();
            String ccyValue = inputElement[1].trim();
            String termsCcyCode = inputElement[3].trim();
            return fxCalculate(baseCcyCode, termsCcyCode, ccyValue);
        }else{
            return INPUT_FORMAT_INCORRECT;
        }
    }

    public String fxCalculate(String baseCcyCode, String termsCcyCode, String ccyValue){
        String convertedCcy = "";
        BigDecimal ccyAmout = new BigDecimal(ccyValue);
        if(!currencyValidator.validate(baseCcyCode, termsCcyCode, ccyList)){
            return generateUnableToFindRateResult(baseCcyCode, termsCcyCode);
        }else{
            Currency ccy = ccyList.stream().filter(c -> c.getCcyCode().equals(termsCcyCode)).findFirst().get();
            BigDecimal b = convert(baseCcyCode, termsCcyCode, null, ccyAmout).setScale(ccy.getPrecision(), RoundingMode.HALF_UP);
            convertedCcy = b.toPlainString();
        }
        return String.format(CONVERT_RESULT, baseCcyCode, ccyValue, termsCcyCode, convertedCcy);
    }

    public BigDecimal convert(String baseCcyCode, String termsCcyCode, String crossViaCcyCode, BigDecimal ccyAmout){
        BigDecimal convertedCcyAmout = ccyAmout;
        int baseCcyMatrixPosition = 0;
        for(int i=1; i < crossViaMatrix.length; i++){
            if(baseCcyCode.equals(crossViaMatrix[i][0])){
                baseCcyMatrixPosition = i;
                break;
            }
        }

        int termsCcyMatrixPosition = 0;
        for(int i=1; i < crossViaMatrix[0].length; i++){
            if(termsCcyCode.equals(crossViaMatrix[0][i])){
                termsCcyMatrixPosition = i;
                break;
            }
        }

        String crossViaValue = crossViaMatrix[baseCcyMatrixPosition][termsCcyMatrixPosition];
        if(crossViaValue.equals(CrossViaTypeEnum.D.getType())){
            CurrencyPairRate c = ccyPairRateList.stream().filter(ccyPairRate -> ccyPairRate.getBase().getCcyCode().equals(baseCcyCode)
                    && ccyPairRate.getTerms().getCcyCode().equals(termsCcyCode)).findFirst().get();
            convertedCcyAmout = convertedCcyAmout.multiply(c.getRate());
        }else if(crossViaValue.equals(CrossViaTypeEnum.INV.getType())){
            CurrencyPairRate c = ccyPairRateList.stream().filter(ccyPairRate -> ccyPairRate.getTerms().getCcyCode().equals(baseCcyCode)
                    && ccyPairRate.getBase().getCcyCode().equals(termsCcyCode)).findFirst().get();
            convertedCcyAmout = convertedCcyAmout.divide(c.getRate(), 10, RoundingMode.HALF_UP);
        }else if(crossViaValue.equals(CrossViaTypeEnum.UNITY.getType())){
            convertedCcyAmout = convertedCcyAmout;
        }else{
            convertedCcyAmout = convert(baseCcyCode, crossViaValue, crossViaValue, ccyAmout);
            convertedCcyAmout = convert(crossViaValue, termsCcyCode, crossViaValue, convertedCcyAmout);
        }
        return convertedCcyAmout;
    }

    public String generateUnableToFindRateResult(String baseCcyCode, String termsCcyCode){
        return String.format(UNABLE_TO_FIND_RATE, baseCcyCode, termsCcyCode);
    }

}
