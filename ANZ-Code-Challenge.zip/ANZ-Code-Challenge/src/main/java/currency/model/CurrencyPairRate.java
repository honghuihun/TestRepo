package currency.model;

import java.math.BigDecimal;

public class CurrencyPairRate {
    private Currency base;
    private Currency terms;
    private BigDecimal rate;

    public CurrencyPairRate(Currency base, Currency terms, BigDecimal rate) {
        this.base = base;
        this.terms = terms;
        this.rate = rate;
    }

    public Currency getBase() {
        return base;
    }

    public Currency getTerms() {
        return terms;
    }

    public BigDecimal getRate() {
        return rate;
    }
}
