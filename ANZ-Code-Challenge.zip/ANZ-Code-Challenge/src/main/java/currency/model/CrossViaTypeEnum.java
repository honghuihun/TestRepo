package currency.model;

public enum CrossViaTypeEnum {
    INV("Inv"), D("D"), UNITY("1:1"), USD("USD"), EUR("EUR");

    private String type;

    CrossViaTypeEnum(String type) {
        this.type = type;
    }

    public String getType(){
        return this.type;
    }
}
