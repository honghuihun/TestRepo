package currency.model;

public class Currency {
    private String ccyCode;
    private int precision;

    public Currency(String ccyCode) {
        this.ccyCode = ccyCode;
    }

    public Currency(String ccyCode, int precision) {
        this.ccyCode = ccyCode;
        this.precision = precision;
    }

    public String getCcyCode() {
        return ccyCode;
    }

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }
}
