package currency.resources.loader;

import currency.model.Currency;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

public class CurrencyLoader {
    private static final String FILE_NAME = "currency-display-precision.properties";
    private static final Logger logger = Logger.getLogger(CurrencyLoader.class.getName());

    public static List<Currency> loadCurrencyDisplayPrecision(){
        List<Currency> ccyList = new ArrayList<>();
        try {
            InputStream in = ClassLoader.getSystemResourceAsStream(FILE_NAME);
            Properties currencyDisplayPrecision = new Properties();
            currencyDisplayPrecision.load(in);
            currencyDisplayPrecision.entrySet().forEach(c -> {
                Currency ccy = new Currency(c.getKey().toString().trim(), Integer.parseInt(c.getValue().toString().trim()));
                ccyList.add(ccy);
            });
        } catch (Exception e) {
            logger.severe("error while loading file " + FILE_NAME);
        }
        return ccyList;
    }
}
