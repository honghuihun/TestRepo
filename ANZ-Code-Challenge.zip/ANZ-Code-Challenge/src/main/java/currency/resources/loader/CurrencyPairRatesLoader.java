package currency.resources.loader;

import currency.model.Currency;
import currency.model.CurrencyPairRate;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Logger;

public class CurrencyPairRatesLoader {
    private static final String FILE_NAME = "currency-pair-rates.properties";
    private static final Logger logger = Logger.getLogger(CurrencyPairRatesLoader.class.getName());

    public static List<CurrencyPairRate> loadCurrencyPairRates(){
        List<CurrencyPairRate> currencyPairRatesList = new ArrayList<>();
        try {
            InputStream in = ClassLoader.getSystemResourceAsStream(FILE_NAME);
            Properties currencyPairRatesProperties = new Properties();
            currencyPairRatesProperties.load(in);
            currencyPairRatesProperties.entrySet().forEach(c -> {
                // in case base and terms are in AUD/USD format
                String key = c.getKey().toString().replace("/", "").trim();
                if(key.length() == 6){
                    Currency base = new Currency(key.substring(0, 3));
                    Currency terms = new Currency(key.substring(3));
                    BigDecimal rate = new BigDecimal(c.getValue().toString().trim());
                    CurrencyPairRate currencyPairRate = new CurrencyPairRate(base, terms, rate);
                    currencyPairRatesList.add(currencyPairRate);
                }
            });
        } catch (Exception e) {
            logger.severe("error while loading file " + FILE_NAME);
        }
        return currencyPairRatesList;
    }
}
