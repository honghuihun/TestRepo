package currency.resources.loader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

public class CrossViaMatrixLoader {
    private static final String FILE_NAME = "cross-via-matrix.txt";
    private static final Logger logger = Logger.getLogger(CrossViaMatrixLoader.class.getName());

    public static String[][] loadCrossViaMatrix(){
        try {
            InputStream in = ClassLoader.getSystemResourceAsStream(FILE_NAME);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));;
            List<String> data = new ArrayList<String>();

            String s;
            while((s = bufferedReader.readLine()) != null) {
                data.add(s);
            }
            bufferedReader.close();

            int matrixDimensionX = data.get(0).split("\\s+").length;
            int matrixDimensionY = data.size();
            String[][] matrix = new String[matrixDimensionX][matrixDimensionY];
            for(int i=0; i<data.size(); i++){
                String[] lineElements = data.get(i).split("\\s+");
                for(int j=0; j<lineElements.length; j++){
                    matrix[i][j] = lineElements[j].trim();
                }
            }
            return matrix;
        } catch (Exception e) {
            logger.severe("error while loading file " + FILE_NAME);
            return null;
        }
    }
}
