package currency;

import java.util.Scanner;

public class Application {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("To use FXCalculator, please input in this format 'AUD 100.00 in USD', input exit to quit application");
        FXCalculator fxCalculator = new FXCalculator();
        String input;
        while(!(input = sc.nextLine().trim()).equals("exit")){
            String response = fxCalculator.processRequest(input);
            System.out.println(response);
        }
    }
}
