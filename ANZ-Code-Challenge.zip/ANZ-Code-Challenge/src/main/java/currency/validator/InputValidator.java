package currency.validator;


import java.math.BigDecimal;

public class InputValidator {

    public boolean validate(String input){
        boolean result = false;
        if(input == null || input.isEmpty()){
            result = false;
        }else{
            String[] inputElement = input.split("\\s+");
            try {
                if(inputElement.length != 4){
                    result = false;
                }else{
                    BigDecimal ccyValue = new BigDecimal(inputElement[1].trim());
                    result = true;
                }
            }catch (NumberFormatException e){
                result = false;
            }
        }
        return result;
    }
}
