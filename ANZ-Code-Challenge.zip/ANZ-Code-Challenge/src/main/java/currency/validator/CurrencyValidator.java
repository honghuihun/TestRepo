package currency.validator;

import currency.model.Currency;

import java.util.List;

public class CurrencyValidator {
    public boolean validate(String baseCcyCode, List<Currency> ccyList){
        long baseCcyFound = ccyList.stream().filter(c -> c.getCcyCode().equals(baseCcyCode)).count();
        return baseCcyFound != 0;
    }

    public boolean validate(String baseCcyCode, String termsCcyCode, List<Currency> ccyList){
        long baseCcyFound = ccyList.stream().filter(c -> c.getCcyCode().equals(baseCcyCode)).count();
        long termsCcyFound = ccyList.stream().filter(c -> c.getCcyCode().equals(termsCcyCode)).count();
        return baseCcyFound != 0 && termsCcyFound != 0;
    }
}
